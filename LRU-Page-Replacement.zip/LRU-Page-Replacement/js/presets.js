/** Example inputs for demonstrating when the two algorithms agree or differ. */
export const PRESETS = [
  {
    id: "basic",
    label: "Basic example (both behave the same)",
    referenceString: "7 0 1 2 0 3 0 4 2 3",
    frameCount: "3",
    note: "Both algorithms give 8 faults here, so LRU-K brings no benefit on this input.",
  },
  {
    id: "scan",
    label: "Hot pages + one-time scan (LRU-K wins)",
    referenceString: "1 2 1 2 1 2 3 4 5 6 7 8 1 2 1 2",
    frameCount: "3",
    note: "Pages 1 and 2 are used repeatedly; 3 to 8 are used once. LRU lets the scan push out the hot pages, LRU-K keeps them.",
  },
  {
    id: "shift",
    label: "Working set changes (LRU wins)",
    referenceString: "1 2 3 1 2 3 4 5 4 5 4 5 4 5",
    frameCount: "3",
    note: "Pages 4 and 5 become the new hot set. LRU-K needs two references per page before trusting it, so it adapts more slowly.",
  },
];
