/**
 * Pure LRU page replacement logic. No DOM access.
 * Recency is tracked with "lastUsedAt": the step number at which each page was last referenced.
 * The victim is the resident page with the smallest lastUsedAt value.
 */

export const STATUS = Object.freeze({ HIT: "Hit", FAULT: "Fault" });

function findLeastRecentlyUsedIndex(frames, lastUsedAt) {
  let victimIndex = 0;
  for (let i = 1; i < frames.length; i++) {
    if (lastUsedAt.get(frames[i]) < lastUsedAt.get(frames[victimIndex])) {
      victimIndex = i;
    }
  }
  return victimIndex;
}

export function snapshotFrames(frames, frameCount) {
  return Array.from({ length: frameCount }, (_, i) => (i < frames.length ? frames[i] : null));
}

/**
 * @param {number[]} referencePages
 * @param {number} frameCount
 * @returns {{steps: object[], pageFaults: number, pageHits: number, totalReferences: number}}
 */
export function simulateLRU(referencePages, frameCount) {
  const frames = [];
  const lastUsedAt = new Map();
  const steps = [];
  let pageFaults = 0;
  let pageHits = 0;

  referencePages.forEach((page, index) => {
    const stepNumber = index + 1;
    const isHit = frames.includes(page);
    let replacedPage = null;
    let replacedLastUsedAt = null;
    let insertedFrameIndex = null;

    if (isHit) {
      pageHits++;
    } else {
      pageFaults++;
      if (frames.length < frameCount) {
        frames.push(page);
        insertedFrameIndex = frames.length - 1;
      } else {
        insertedFrameIndex = findLeastRecentlyUsedIndex(frames, lastUsedAt);
        replacedPage = frames[insertedFrameIndex];
        replacedLastUsedAt = lastUsedAt.get(replacedPage);
        lastUsedAt.delete(replacedPage);
        frames[insertedFrameIndex] = page;
      }
    }

    lastUsedAt.set(page, stepNumber);

    steps.push({
      stepNumber,
      page,
      frames: snapshotFrames(frames, frameCount),
      status: isHit ? STATUS.HIT : STATUS.FAULT,
      replacedPage,
      replacedLastUsedAt,
      insertedFrameIndex,
    });
  });

  return { steps, pageFaults, pageHits, totalReferences: referencePages.length };
}
