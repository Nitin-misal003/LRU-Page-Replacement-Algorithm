/** Connects validation, algorithms, metrics and UI. */
import { simulateLRU } from "./lru.js";
import { simulateLRUK } from "./lruk.js";
import { validateReferenceString, validateFrameCount, validateKValue } from "./validation.js";
import { calculateMetrics, compareMetrics } from "./metrics.js";
import { PRESETS } from "./presets.js";
import * as ui from "./ui.js";

function runAlgorithm(simulation) {
  return { steps: simulation.steps, metrics: calculateMetrics(simulation) };
}

function handleRunSimulation(event) {
  event.preventDefault();
  ui.clearErrors();

  const { referenceString, frameCount, k } = ui.getInputValues();
  const referenceCheck = validateReferenceString(referenceString);
  const frameCheck = validateFrameCount(frameCount);
  const kCheck = validateKValue(k);

  const errors = [...referenceCheck.errors, ...frameCheck.errors, ...kCheck.errors];
  if (errors.length > 0) {
    ui.displayErrors(errors);
    return;
  }

  const lru = runAlgorithm(simulateLRU(referenceCheck.pages, frameCheck.frameCount));
  const lruk = runAlgorithm(simulateLRUK(referenceCheck.pages, frameCheck.frameCount, kCheck.k));
  const comparison = compareMetrics(lru.metrics, lruk.metrics);
  ui.displayResults({ lru, lruk, comparison, frameCount: frameCheck.frameCount, k: kCheck.k });
}

function handlePresetChange(event) {
  const preset = PRESETS.find((p) => p.id === event.target.value);
  if (!preset) {
    ui.showPresetNote("");
    return;
  }
  ui.setInputValues({ referenceString: preset.referenceString, frameCount: preset.frameCount });
  ui.showPresetNote(preset.note);
}

function handleReset() {
  ui.clearResults();
  ui.resetInputs();
}

ui.populatePresets(PRESETS);
document.getElementById("simulation-form").addEventListener("submit", handleRunSimulation);
document.getElementById("reset-button").addEventListener("click", handleReset);
document.getElementById("preset-select").addEventListener("change", handlePresetChange);
