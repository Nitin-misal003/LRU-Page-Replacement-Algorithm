/** DOM rendering only. Contains no algorithm or metric calculations. */
import { STATUS } from "./lru.js";

const byId = (id) => document.getElementById(id);

const elements = {
  referenceInput: byId("reference-string"),
  frameInput: byId("frame-count"),
  kInput: byId("k-value"),
  presetSelect: byId("preset-select"),
  presetNote: byId("preset-note"),
  errorList: byId("error-list"),
  results: byId("results"),
  comparisonTable: byId("comparison-table"),
  verdict: byId("comparison-verdict"),
};

const views = {
  lru: { table: byId("table-lru"), explanation: byId("explanation-lru"), metrics: byId("metrics-lru"), title: byId("title-lru") },
  lruk: { table: byId("table-lruk"), explanation: byId("explanation-lruk"), metrics: byId("metrics-lruk"), title: byId("title-lruk") },
};

export const DEFAULT_INPUTS = { referenceString: "7 0 1 2 0 3 0 4 2 3", frameCount: "3", k: "2" };

export function getInputValues() {
  return {
    referenceString: elements.referenceInput.value,
    frameCount: elements.frameInput.value,
    k: elements.kInput.value,
  };
}

export function setInputValues({ referenceString, frameCount, k }) {
  if (referenceString !== undefined) elements.referenceInput.value = referenceString;
  if (frameCount !== undefined) elements.frameInput.value = frameCount;
  if (k !== undefined) elements.kInput.value = k;
}

export function populatePresets(presets) {
  const placeholder = new Option("Choose an example…", "");
  elements.presetSelect.replaceChildren(placeholder, ...presets.map((p) => new Option(p.label, p.id)));
}

export function showPresetNote(text) {
  elements.presetNote.textContent = text;
}

function createElement(tag, text = "", className = "") {
  const element = document.createElement(tag);
  element.textContent = text;
  if (className) element.className = className;
  return element;
}

export function buildStepExplanation(step, frameCount, algorithm, k) {
  const prefix = `Step ${step.stepNumber}: `;
  if (step.status === STATUS.HIT) {
    return `${prefix}Page ${step.page} is already in memory, so this is a page hit. No page is replaced and its recent-use information is updated.`;
  }
  if (step.replacedPage === null) {
    return `${prefix}Page ${step.page} caused a page fault. A free frame was available, so it was inserted without replacing any page.`;
  }
  const faultText = `${prefix}Page ${step.page} caused a page fault. All ${frameCount} frames are full, so page ${step.replacedPage} was replaced`;
  if (algorithm === "lru") {
    return `${faultText} because it was the least recently used page (last used at step ${step.replacedLastUsedAt}).`;
  }
  if (step.replacedHasFullHistory) {
    return `${faultText} because it had the largest backward ${k}-distance (its ${k}${ordinalSuffix(k)} most recent reference was at step ${step.replacedKthReference}).`;
  }
  return `${faultText} because it had been referenced fewer than ${k} times (infinite backward ${k}-distance), so LRU-K treats it as a page not yet proven to be hot.`;
}

function ordinalSuffix(number) {
  return { 1: "st", 2: "nd", 3: "rd" }[number] ?? "th";
}

function buildHeaderRow(frameCount) {
  const row = document.createElement("tr");
  const labels = ["Step", "Page"];
  for (let i = 1; i <= frameCount; i++) labels.push(`Frame ${i}`);
  labels.push("Status", "Replaced Page");
  labels.forEach((label) => {
    const cell = createElement("th", label);
    cell.scope = "col";
    row.appendChild(cell);
  });
  return row;
}

function buildStepRow(step) {
  const isHit = step.status === STATUS.HIT;
  const row = document.createElement("tr");
  row.className = isHit ? "hit" : "fault";
  row.tabIndex = 0;

  row.appendChild(createElement("td", step.stepNumber));
  row.appendChild(createElement("td", step.page));
  step.frames.forEach((page, index) => {
    const cell = createElement("td", page === null ? "-" : page);
    if (index === step.insertedFrameIndex) cell.classList.add("inserted");
    row.appendChild(cell);
  });
  row.appendChild(createElement("td", step.status, isHit ? "status-hit" : "status-fault"));
  const hasReplacement = step.replacedPage !== null;
  row.appendChild(createElement("td", hasReplacement ? step.replacedPage : "-", hasReplacement ? "replaced" : ""));
  return row;
}

function frameSetKey(frames) {
  return frames.map((page) => (page === null ? -1 : page)).sort((a, b) => a - b).join(",");
}

function renderStepTable({ view, steps, frameCount, algorithm, k, baselineSteps }) {
  const rows = steps.map((step, index) => {
    const row = buildStepRow(step);
    if (baselineSteps && frameSetKey(step.frames) !== frameSetKey(baselineSteps[index].frames)) {
      row.classList.add("differs");
    }
    const select = () => {
      rows.forEach((r) => r.classList.remove("selected"));
      row.classList.add("selected");
      view.explanation.textContent = buildStepExplanation(step, frameCount, algorithm, k);
    };
    row.addEventListener("click", select);
    row.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        select();
      }
    });
    return row;
  });

  const head = document.createElement("thead");
  head.appendChild(buildHeaderRow(frameCount));
  const body = document.createElement("tbody");
  body.append(...rows);
  view.table.replaceChildren(head, body);

  const last = rows.length - 1;
  rows[last].classList.add("selected");
  view.explanation.textContent = buildStepExplanation(steps[last], frameCount, algorithm, k);
}

function renderMetricCards(container, metrics) {
  const cards = [
    ["Total References", metrics.totalReferences],
    ["Page Faults", metrics.pageFaults],
    ["Page Hits", metrics.pageHits],
    ["Page Fault Rate", `${metrics.pageFaultRate}%`],
    ["Page Hit Rate", `${metrics.pageHitRate}%`],
  ];
  const nodes = cards.map(([label, value]) => {
    const card = createElement("div", "", "metric");
    card.append(createElement("span", value, "value"), createElement("span", label, "label"));
    return card;
  });
  container.replaceChildren(...nodes);
}

function signed(value) {
  const number = Number(value);
  return number > 0 ? `+${value}` : `${value}`;
}

function renderComparison(lruMetrics, lrukMetrics, comparison, k) {
  const head = document.createElement("thead");
  const headRow = document.createElement("tr");
  ["Metric", "Traditional LRU", `LRU-${k}`, `Difference (LRU-${k} vs LRU)`].forEach((label) => {
    const cell = createElement("th", label);
    cell.scope = "col";
    headRow.appendChild(cell);
  });
  head.appendChild(headRow);

  const rows = [
    ["Page Faults", lruMetrics.pageFaults, lrukMetrics.pageFaults, signed(-comparison.faultDifference)],
    ["Page Hits", lruMetrics.pageHits, lrukMetrics.pageHits, signed(comparison.hitDifference)],
    ["Page Fault Rate", `${lruMetrics.pageFaultRate}%`, `${lrukMetrics.pageFaultRate}%`, `${signed(-comparison.faultRateDifference)} pts`],
    ["Page Hit Rate", `${lruMetrics.pageHitRate}%`, `${lrukMetrics.pageHitRate}%`, `${signed(comparison.faultRateDifference)} pts`],
  ].map((cells) => {
    const row = document.createElement("tr");
    cells.forEach((text, i) => row.appendChild(createElement(i === 0 ? "th" : "td", text)));
    row.firstChild.scope = "row";
    return row;
  });

  const body = document.createElement("tbody");
  body.append(...rows);
  elements.comparisonTable.replaceChildren(head, body);

  const verdicts = {
    "LRU-K": `LRU-${k} had ${comparison.faultDifference} fewer page fault(s) than traditional LRU on this input.`,
    LRU: `Traditional LRU had ${-comparison.faultDifference} fewer page fault(s) than LRU-${k} on this input.`,
    Tie: `Both algorithms produced the same number of page faults on this input.`,
  };
  elements.verdict.textContent = verdicts[comparison.winner];
}

export function displayResults({ lru, lruk, comparison, frameCount, k }) {
  views.lru.title.textContent = "Traditional LRU";
  views.lruk.title.textContent = `Research-based: LRU-${k}`;
  renderComparison(lru.metrics, lruk.metrics, comparison, k);
  renderMetricCards(views.lru.metrics, lru.metrics);
  renderMetricCards(views.lruk.metrics, lruk.metrics);
  renderStepTable({ view: views.lru, steps: lru.steps, frameCount, algorithm: "lru", k });
  renderStepTable({ view: views.lruk, steps: lruk.steps, frameCount, algorithm: "lruk", k, baselineSteps: lru.steps });
  elements.results.hidden = false;
}

export function displayErrors(messages) {
  elements.errorList.replaceChildren(...messages.map((message) => createElement("li", message)));
  elements.errorList.hidden = false;
  elements.results.hidden = true;
}

export function clearErrors() {
  elements.errorList.replaceChildren();
  elements.errorList.hidden = true;
}

export function clearResults() {
  clearErrors();
  Object.values(views).forEach((view) => {
    view.table.replaceChildren();
    view.metrics.replaceChildren();
    view.explanation.textContent = "";
  });
  elements.comparisonTable.replaceChildren();
  elements.verdict.textContent = "";
  elements.results.hidden = true;
}

export function resetInputs() {
  setInputValues({ referenceString: DEFAULT_INPUTS.referenceString, frameCount: DEFAULT_INPUTS.frameCount, k: DEFAULT_INPUTS.k });
  elements.presetSelect.value = "";
  showPresetNote("");
  elements.referenceInput.focus();
}
