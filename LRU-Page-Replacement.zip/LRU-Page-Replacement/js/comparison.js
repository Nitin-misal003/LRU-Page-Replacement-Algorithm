/** Compares two simulation results step by step. No DOM access. */

function isDifferentDecision(lruStep, lrukStep) {
  return lruStep.status !== lrukStep.status || lruStep.replacedPage !== lrukStep.replacedPage;
}

export function findDifferingSteps(lruResult, lrukResult) {
  return lruResult.steps
    .map((lruStep, index) => ({ lruStep, lrukStep: lrukResult.steps[index] }))
    .filter(({ lruStep, lrukStep }) => isDifferentDecision(lruStep, lrukStep));
}

export function buildVerdict(lruResult, lrukResult, k) {
  const faultsSaved = lruResult.pageFaults - lrukResult.pageFaults;
  const differingCount = findDifferingSteps(lruResult, lrukResult).length;

  if (faultsSaved === 0) {
    return differingCount === 0
      ? `Both algorithms made identical decisions at every step (${lruResult.pageFaults} faults each).`
      : `Both algorithms produced ${lruResult.pageFaults} page faults, but they chose differently at ${differingCount} step(s).`;
  }

  const better = faultsSaved > 0 ? `LRU-${k}` : "traditional LRU";
  const improvement = (Math.abs(faultsSaved) / Math.max(lruResult.pageFaults, lrukResult.pageFaults)) * 100;
  return `${better} performed better on this input: ${Math.abs(faultsSaved)} fewer page fault(s) (${improvement.toFixed(2)}% fewer than the other algorithm).`;
}
