/** Input validation. Each function returns { valid, errors, ...parsedValue }. */

export const MAX_FRAMES = 10;
export const MAX_REFERENCES = 100;
export const MAX_PAGE_NUMBER = 999;
export const MIN_K = 1;
export const MAX_K = 4;

const REFERENCE_PATTERN = /^\d+([\s,]+\d+)*$/;

export function validateReferenceString(rawValue) {
  const text = rawValue.trim();
  if (text === "") {
    return { valid: false, errors: ["Reference string is empty. Enter page numbers such as: 7 0 1 2 0 3."] };
  }
  if (!REFERENCE_PATTERN.test(text)) {
    return {
      valid: false,
      errors: ["Reference string may contain only non-negative whole numbers separated by spaces or commas (no letters, signs, decimals or other separators)."],
    };
  }

  const pages = text.split(/[\s,]+/).map(Number);
  const errors = [];
  if (pages.length > MAX_REFERENCES) {
    errors.push(`Reference string has ${pages.length} pages. The limit is ${MAX_REFERENCES}.`);
  }
  if (pages.some((page) => page > MAX_PAGE_NUMBER)) {
    errors.push(`Page numbers must not exceed ${MAX_PAGE_NUMBER}.`);
  }
  return errors.length > 0 ? { valid: false, errors } : { valid: true, errors: [], pages };
}

export function validateFrameCount(rawValue) {
  const text = rawValue.trim();
  if (text === "") {
    return { valid: false, errors: ["Number of frames is empty. Enter a whole number such as 3."] };
  }
  if (!/^-?\d+(\.\d+)?$/.test(text)) {
    return { valid: false, errors: ["Number of frames must be a number."] };
  }

  const value = Number(text);
  if (!Number.isInteger(value)) {
    return { valid: false, errors: ["Number of frames must be a whole number, not a decimal."] };
  }
  if (value <= 0) {
    return { valid: false, errors: ["Number of frames must be at least 1."] };
  }
  if (value > MAX_FRAMES) {
    return { valid: false, errors: [`Number of frames must not exceed ${MAX_FRAMES}.`] };
  }
  return { valid: true, errors: [], frameCount: value };
}

export function validateKValue(rawValue) {
  const value = Number(String(rawValue).trim());
  if (!Number.isInteger(value) || value < MIN_K || value > MAX_K) {
    return { valid: false, errors: [`K must be a whole number from ${MIN_K} to ${MAX_K}.`] };
  }
  return { valid: true, errors: [], k: value };
}
