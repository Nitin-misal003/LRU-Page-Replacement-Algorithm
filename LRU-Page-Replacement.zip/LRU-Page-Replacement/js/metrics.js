/** Performance calculations. No DOM access. */

const DECIMAL_PLACES = 2;

function toPercentage(part, total) {
  return total === 0 ? 0 : (part / total) * 100;
}

export function calculatePageFaultRate(pageFaults, totalReferences) {
  return toPercentage(pageFaults, totalReferences);
}

export function calculatePageHitRate(pageHits, totalReferences) {
  return toPercentage(pageHits, totalReferences);
}

export function calculateMetrics({ pageFaults, pageHits, totalReferences }) {
  return {
    totalReferences,
    pageFaults,
    pageHits,
    pageFaultRate: calculatePageFaultRate(pageFaults, totalReferences).toFixed(DECIMAL_PLACES),
    pageHitRate: calculatePageHitRate(pageHits, totalReferences).toFixed(DECIMAL_PLACES),
  };
}

/** Compares traditional LRU against the research-based algorithm. Positive differences favour LRU-K. */
export function compareMetrics(lruMetrics, lrukMetrics) {
  const faultDifference = lruMetrics.pageFaults - lrukMetrics.pageFaults;
  const winner = faultDifference > 0 ? "LRU-K" : faultDifference < 0 ? "LRU" : "Tie";
  return {
    faultDifference,
    hitDifference: lrukMetrics.pageHits - lruMetrics.pageHits,
    faultRateDifference: (Number(lruMetrics.pageFaultRate) - Number(lrukMetrics.pageFaultRate)).toFixed(DECIMAL_PLACES),
    winner,
  };
}
