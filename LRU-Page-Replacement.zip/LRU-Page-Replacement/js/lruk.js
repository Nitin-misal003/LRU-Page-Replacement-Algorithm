/**
 * LRU-K page replacement (O'Neil, O'Neil & Weikum, SIGMOD 1993). No DOM access.
 *
 * Instead of only the last reference, LRU-K remembers the times of the last K references of each page.
 * Backward K-distance = currentTime - (time of the K-th most recent reference).
 * Victim = resident page with the LARGEST backward K-distance.
 * A page with fewer than K references has an infinite distance, so it is evicted first;
 * ties among such pages are broken with ordinary LRU (oldest last reference).
 *
 * Simplification: reference history is kept even after a page is evicted
 * (the paper limits this with a "Retained Information Period").
 */
import { STATUS } from "./lru.js";

export const DEFAULT_K = 2;

function getKthReferenceTime(history, k) {
  return history.length >= k ? history[history.length - k] : -Infinity;
}

function getLastReferenceTime(history) {
  return history[history.length - 1];
}

function isBetterVictim(candidateHistory, currentVictimHistory, k) {
  const candidateKth = getKthReferenceTime(candidateHistory, k);
  const victimKth = getKthReferenceTime(currentVictimHistory, k);
  if (candidateKth !== victimKth) return candidateKth < victimKth;
  return getLastReferenceTime(candidateHistory) < getLastReferenceTime(currentVictimHistory);
}

function findVictimIndex(frames, histories, k) {
  let victimIndex = 0;
  for (let i = 1; i < frames.length; i++) {
    if (isBetterVictim(histories.get(frames[i]), histories.get(frames[victimIndex]), k)) {
      victimIndex = i;
    }
  }
  return victimIndex;
}

function recordReference(histories, page, time, k) {
  const history = histories.get(page) ?? [];
  history.push(time);
  if (history.length > k) history.shift();
  histories.set(page, history);
}

function snapshotFrames(frames, frameCount) {
  return Array.from({ length: frameCount }, (_, i) => (i < frames.length ? frames[i] : null));
}

export function simulateLRUK(referencePages, frameCount, k = DEFAULT_K) {
  const frames = [];
  const histories = new Map();
  const steps = [];
  let pageFaults = 0;
  let pageHits = 0;

  referencePages.forEach((page, index) => {
    const stepNumber = index + 1;
    const isHit = frames.includes(page);
    let replacedPage = null;
    let replacedKthReference = null;
    let replacedHasFullHistory = null;
    let insertedFrameIndex = null;

    if (isHit) {
      pageHits++;
    } else {
      pageFaults++;
      if (frames.length < frameCount) {
        frames.push(page);
        insertedFrameIndex = frames.length - 1;
      } else {
        insertedFrameIndex = findVictimIndex(frames, histories, k);
        replacedPage = frames[insertedFrameIndex];
        const victimHistory = histories.get(replacedPage);
        replacedHasFullHistory = victimHistory.length >= k;
        replacedKthReference = replacedHasFullHistory ? getKthReferenceTime(victimHistory, k) : null;
        frames[insertedFrameIndex] = page;
      }
    }

    recordReference(histories, page, stepNumber, k);

    steps.push({
      stepNumber,
      page,
      frames: snapshotFrames(frames, frameCount),
      status: isHit ? STATUS.HIT : STATUS.FAULT,
      replacedPage,
      replacedKthReference,
      replacedHasFullHistory,
      insertedFrameIndex,
    });
  });

  return { steps, pageFaults, pageHits, totalReferences: referencePages.length };
}
